Ciclop by bq is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License:
 ( http://creativecommons.org/licenses/by-sa/4.0/ )

Permissions beyond the scope of this license may be available at http://www.bq.com
